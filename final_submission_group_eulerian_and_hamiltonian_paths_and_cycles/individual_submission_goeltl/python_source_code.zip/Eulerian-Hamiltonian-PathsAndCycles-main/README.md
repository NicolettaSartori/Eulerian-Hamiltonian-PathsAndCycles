# Eulerian-Hamiltonian-PathsAndCycles

```shell
uv run ./dynamic/dynamic_exercises.py
```